const app = new Vue({
    el: '#app2',
    data() {
      return {
        activities: [{
          content: '已收货（对应状态）',
          timestamp: '2018-04-12 20:46（对应发生时间' +
              '已收货，请耐心等待（对应描述）',
          size: 'large',
          type: 'primary',
          icon: 'el-icon-more'
        }, {
          content: '支持自定义颜色',
          timestamp: '2018-04-03 20:46',
          color: '#0bbd87'
        }, {
          content: '支持自定义尺寸',
          timestamp: '2018-04-03 20:46',
          size: 'large'
        }, {
          content: '默认样式的节点',
          timestamp: '2018-04-03 20:46'
        }]
      };
    }
})