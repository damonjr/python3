const app = new Vue({
    el: '#app',
    data: {
        tableData: [],
        pageTableData: [],//分页后显示当前页信息
        // 后端请求地址
        baseURL: "http://127.0.0.1:8000/",
        input_hbl: '',//HBL 查询条件

        total: 0, //数据总行数
        currentpage: 1,//当前所在的页面
        pagesize: 10, //每页显示多少行
        //对话框默认不显示
        dialogVisible:false,
        dialogTitle:"",//弹出框标题
        isView:false, //是否为查看
        isEdit:false, //是否是维护
        ordersForm:{
            hbl_num:'',
            big_ticket_num:'',
            hbl_status:'',
            create_date:'',
            hbl_creator:'',
            hbl_remake: '',
        },
        rules: {
            hbl_num: [
                {required: true, message: "不能为空", trigger: 'blur'},
                {pattern: /^[A-Za-z0-9_]+$/, message: '只能存在数字、字母、下划线', triggler: 'blur'},
            ],
            // // big_ticket_num: [],
            hbl_status: [
                {required: true, message: "不能为空", trigger: 'blur'},
            ]
            // create_date: [],
            // hbl_creator: [],
            // hbl_remake: [],
        },

    },

    mounted() {
        this.get_hbl()
    },
    methods: {
        get_hbl: function () {
            // 记录this的地址
            let that =this
            //使用Axios实现Ajax请求
            axios
                .get(this.baseURL + "hbl/")
                .then(function (res) {
                    console.log(res)
                    //请求成功后执行的函数
                    if (res.data.code === 1) {
                        // 把数据给表格
                        that.tableData = res.data.data;
                        //获取返回记录的总行数
                        that.total = res.data.data.length
                        //获取当前页的数据
                        that.getPageTableData()
                        // 提示；
                        that.$message({
                            showClose: true,
                            message: '数据加载成功',
                            type: 'success'
                        });
                    } else {
                        // 失败的提示
                        that.$message.error({
                            showClose: true,
                            message: res.data.msg,
                            type: 'error'
                        });
                    }
                })
                .catch(function (err) {
                    console.log(err)
                })
        },
        //重置
        get_AllOrders(){
            //清空搜索框
            this.input_hbl =""
            this.get_hbl()

        },
        // 获取当前页的数据
        getPageTableData(){
            // 清空PageTableData的数据
            this.pageTableData = [];
            for (let i=(this.currentpage - 1)* this.pagesize; i< this.total;i++){
                //遍历数据添加到PageTableData
                this.pageTableData.push(this.tableData[i]);
                //判断是否达到一页的要求
                if (this.pageTableData.length == this.pagesize) break;
            }
        },
        // 查询
        queryOrders(){
            // 使用ajax请求--post-->传递数据
            let that = this
            //开始ajax请求
            axios
                .post(
                    that.baseURL + "hbl/query/",
                    {
                        inputstr: that.input_hbl
                    }
                )
                .then(function (res){
                    if (res.data.code === 1){
                        that.tableData = res.data.data
                        //获取返回记录的总行数
                        that.total = res.data.data.length
                        //获取当前页的数据
                        that.getPageTableData()
                        // 提示；
                        that.$message({
                            showClose: true,
                            message: '数据加载成功',
                            type: 'success'
                            });
                    }else {
                        // 失败的提示
                        that.$message.error({
                            showClose: true,
                            message: res.data.msg,
                            type: 'error'
                        });

                    }

                })
                .catch(function (err){
                    console.log(err)
                    that.$message.error("获取数据异常！");
                });
        },
        // 新增数据
        addorder(){
            this.dialogTitle = "新增";
            this.dialogVisible = true;
        },
        //分页时修改每一页的行数
        handleSizeChange(size){
            //修改当前页行数
            this.pagesize = size;
            // 将数据重新分页
            this.getPageTableData()
        },
        //查看明细
        viewOrder(row){
            this.dialogTitle = "查看";
            //弹出表单
            this.dialogVisible = "true";
            this.isView = true;
            // console.log(row)
            // 深拷贝复制01
            // this.ordersForm.hbl_num = row.hbl_num;
            // this.ordersForm.big_ticket_num = row.big_ticket_num;
            // this.ordersForm.hbl_status = row.hbl_status;
            // this.ordersForm.create_date = row.create_date;
            // this.ordersForm.hbl_creator = row.hbl_creator;
            // this.ordersForm.hbl_remake = row.hbl_remake;
            //深拷贝复制02
            this.ordersForm = JSON.parse(JSON.stringify(row));

        },
        //维护明细
        updateOrder(row){
            // 标题修改
            this.dialogTitle = "维护";
            this.isEdit = true;
            //弹出表单
            this.dialogVisible = "true" ;
            this.ordersForm = JSON.parse(JSON.stringify(row));

        },
        //关闭弹窗并清空表单缓存
        closeDialogForm(){
          //清空
            this.ordersForm.hbl_num = "";
            this.ordersForm.big_ticket_num = "";
            this.ordersForm.hbl_status = "";
            this.ordersForm.create_date = "";
            this.ordersForm.hbl_creator = "";
            this.ordersForm.hbl_remake = "";
            this.dialogVisible=false;
            this.isEdit = false;
            this.isView = false;
        },
        //调整当前页码
        handleCurrentChange(pageNumber){
            // 修改当前页的页码
            this.currentpage = pageNumber;
            // 将数据重新分页
            this.getPageTableData();
        }
    },
})